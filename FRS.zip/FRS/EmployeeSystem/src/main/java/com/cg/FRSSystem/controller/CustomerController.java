package com.cg.FRSSystem.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.FRSSystem.bean.Customer;
import com.cg.FRSSystem.service.CustomerService;


/**
 * @author puchekar
 *
 */
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/customer")
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	
	
	
	private final Logger LOG = LoggerFactory.getLogger(getClass());
	
	

	@PostMapping(value = "/create")
	public Customer postCustomer(@RequestBody Customer customer) {
		customer.setRole("customer");
		Customer _customer = customerService.addCustomer(customer);
		LOG.info("Saving Customer  Details...");
		return _customer;
	}
	


	
	
}
