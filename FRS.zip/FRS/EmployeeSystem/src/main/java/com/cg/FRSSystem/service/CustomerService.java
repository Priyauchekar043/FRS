package com.cg.FRSSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.FRSSystem.bean.Customer;
import com.cg.FRSSystem.dao.ICustomerDao;



/**
 * @author puchekar
 *
 */
@Service
public class CustomerService{
	
	@Autowired
	ICustomerDao customerDao;

	public Customer addCustomer(Customer customer) {
		return customerDao.save(customer);
	}
	

	

}
