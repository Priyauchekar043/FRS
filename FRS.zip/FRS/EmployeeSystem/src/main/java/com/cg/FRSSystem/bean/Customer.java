
package com.cg.FRSSystem.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author puchekar
 *
 */
@Entity
@Table(name = "Customer")
public class Customer {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long custId;
	private String name;
	private String lastname;
	private int age;
	private String gender;
	private String dob;
	private String email;
	private String phone;
	@Column(unique = true)
	private String username;
	private String password;
	private String role;
	public Long getCustId() {
		return custId;
	}
	public void setCustId(Long custId) {
		this.custId = custId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", name=" + name + ", lastname=" + lastname + ", age=" + age + ", gender="
				+ gender + ", dob=" + dob + ", email=" + email + ", phone=" + phone + ", username=" + username
				+ ", password=" + password + ", role=" + role + "]";
	}
	public Customer(Long custId, String name, String lastname, int age, String gender, String dob, String email,
			String phone, String username, String password, String role) {
		super();
		this.custId = custId;
		this.name = name;
		this.lastname = lastname;
		this.age = age;
		this.gender = gender;
		this.dob = dob;
		this.email = email;
		this.phone = phone;
		this.username = username;
		this.password = password;
		this.role = role;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	
	
}
