package com.cg.FRSSystem;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author puchekar
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class FRSSystemApplicationTests {

	@Test
	public void contextLoads() {
	}

}
