import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Customer } from '../model/Customer';
import { CustomerService } from '../Customer.service';
import { Router } from "@angular/router";
@Component({
  selector: 'app-add-admin',
  templateUrl: './add-admin.component.html',
  styleUrls: ['./add-admin.component.css']
})
export class AddAdminComponent implements OnInit {
  adminSubmitted: boolean = false;
  addAdminForm: FormGroup;
  cust: Customer = new Customer();
  submitted = false;
  //public today = new Date();


  constructor(private formBuilder: FormBuilder,
     private router: Router, 
     private CustomerService: CustomerService) {

    // this.tomorrow.setDate(this.tomorrow.getDate() + 1);
  }

  ngOnInit() {
    this.addAdminForm = this.formBuilder.group({
      name: ['', [Validators.required,
        Validators.maxLength(50),
        Validators.pattern('^[a-zA-Z ]*$')]],
      lastname: ['', [Validators.required,
        Validators.maxLength(50),
        Validators.pattern('^[a-zA-Z ]*$')]],
        email: ['', [Validators.required, Validators.email,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      phone: ['', [Validators.required, Validators.maxLength(10), Validators.pattern('^[0-9]*$') ]],
      address: ['', Validators.required],
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]]
      
    });
  }
  onSubmit() {
    console.log(this.addAdminForm);
    if (this.addAdminForm.invalid == true) {
      console.log("inavalid")
      return;
    } else
      if (this.addAdminForm.controls) {
        var form = this.addAdminForm.controls;
        this.cust.name = form.name.value;
        this.cust.lastname = form.lastname.value;
        this.cust.email = form.email.value;
        this.cust.phone = form.phone.value;
        this.cust.address = form.address.value;
        this.cust.username = form.username.value;
        this.cust.password = form.password.value;
        


        if (this.cust) {
          this.adminSubmitted = true;
          this.CustomerService.addAdmin(this.cust).subscribe(data => {
            console.log(data);
          });
          alert('Admin Added Successfully...!');
          this.addAdminForm.reset();
        }
       
      }
  }
}


