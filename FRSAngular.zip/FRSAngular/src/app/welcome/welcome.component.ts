import { Component, OnInit,Input,EventEmitter,Output } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import { Customer } from '../model/Customer';
import { CustomerService } from '../Customer.service';
@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {
  title = 'Flight Reservation System';

  @Input() name: string;
  @Output() changeName = new EventEmitter();
  public Role;
  welcomePage = true;
  cust: Customer;
  showAdmin: boolean;
  adminList: Customer[];
  addNewAdminFlag: boolean = false;
  constructor(private authService: AuthenticationService, private custService: CustomerService) { }
  addNewAdmin() {
    this.addNewAdminFlag = true;
     this.showAdmin = false;
     this.welcomePage = false;
     //this.showDeleteAdminFlag = false;
   }
  ngOnInit() {
  }

}
