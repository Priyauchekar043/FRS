export class Customer {
    userId: number;
    name: String;
    age:number;
    gender:String;
    dob:String;
    lastname: String;
    address: String;
    email: String;
    phone: String;
    username: String;
    password: String;
    role: String;
   


    










}
