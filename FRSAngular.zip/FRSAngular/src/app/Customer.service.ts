import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from './model/Customer';
import {Router} from "@angular/router";

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  private baseUrl = 'http://localhost:8081/api/customer';
  newId;
  cust: Customer;
  constructor(private http:HttpClient,private router: Router,) { }

   sendData(data){
    console.log("inside customer data=>",data);
   this.newId = data;
   }
  
  signUp(cust: Customer): Observable<Object>{
    return this.http.post(`${this.baseUrl}` + `/create`, cust);
  }

   addAdmin(admin : Customer):Observable<Object>{
     return this.http.post(`${this.baseUrl}` + `/addAdmin`, admin);
   }

 

   

   getEmpDetail(userId:number){
   return this.http.get<Customer>(`${this.baseUrl}`+`/getEmpDetail/`+userId);
   }
  
   
  
}
