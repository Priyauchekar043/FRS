import { Component, OnInit, Input, Output,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { EventEmitter } from 'events';
import { AuthenticationService } from '../authentication.service';
import { Customer } from '../model/Customer';
import { CustomerService } from '../Customer.service';



@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  ngOnInit(): void {
    throw new Error("Method not implemented.");
  }

  @Input() name: string;
  @Output() changeName = new EventEmitter();
  public Role;
  cust: Customer;
  
  userId: number;
 
 
  
  //showDeleteStudentFlag: boolean = false;
  
  showAdmin: boolean;
  adminList: Customer[];
  addNewAdminFlag: boolean = false;
  
 

  constructor(private authService: AuthenticationService, private custService: CustomerService) {
    this.authService.getEmpDetail().subscribe(data => {
      if (data.role == 'customer') {
        this.Role = data.role;
        this.cust = data;
        this.userId = data.userId;
       //  this.authService.sendEmpDetail(data);
      }
      if (data.role == 'Admin') {
        this.Role = data.role;
        this.cust = data;
        //this.authService.sendEmpDetail(data);
      }
     
      //console.log(data);
    });
  }

  
  
 }

