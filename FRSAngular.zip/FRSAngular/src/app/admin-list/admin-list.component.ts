import { Component, OnInit,Input } from '@angular/core';
import { CustomerService } from '../Customer.service';
import { Customer } from '../model/Customer';

@Component({
  selector: 'app-admin-list',
  templateUrl: './admin-list.component.html',
  styleUrls: ['./admin-list.component.css']
})
export class AdminListComponent implements OnInit {

  @Input() adminList: Customer[];
  searchText;
  constructor(private custService: CustomerService) { }

  ngOnInit() {
  }

}
